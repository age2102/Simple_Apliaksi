<?php
$con = mysqli_connect("localhost", "u902956780_db_imas", "Rast@210", "u902956780_db_imas");
if (mysqli_connect_errno()) {
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
    exit();
}
?>
